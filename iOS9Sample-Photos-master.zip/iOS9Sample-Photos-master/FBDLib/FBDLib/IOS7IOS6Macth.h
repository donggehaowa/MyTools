//
//  ViewController.m
//  BioonApp
//
//  Created by Bioon on 14/11/24.
//  Copyright (c) 2014年 Bioon. All rights reserved.
//

#ifndef ZYCoreDataSuperDemo1_IOS7IOS6Macth_h
#define ZYCoreDataSuperDemo1_IOS7IOS6Macth_h
#import <CoreFoundation/CoreFoundation.h>
//disable loggin on production
#ifdef RELEASE
#define KSLog(format, ...) CFShow((__bridge CFTypeRef)[NSString stringWithFormat:format, ## __VA_ARGS__]);

//#import "Extend_Description.h"

#else
#define KSLog(...)
#endif

#define IsIOS7 ([[[[UIDevice currentDevice] systemVersion] substringToIndex:1] intValue]>=7)
#define CGRECT_NO_NAV(x,y,w,h) CGRectMake((x), (y+(IsIOS7?20:0)), (w), (h))
#define CGRECT_HAVE_NAV(x,y,w,h) CGRectMake((x), (y+(IsIOS7?64:0)), (w), (h))
//by  Box
#define isIPHONE4S ([UIScreen mainScreen].bounds.size.height == 480.0)
#define isIPHONE5 ([UIScreen mainScreen].bounds.size.height == 568.0)
#define isIPHONE6 ([UIScreen mainScreen].bounds.size.height == 667.0)
#define isIPHONE6P ([UIScreen mainScreen].bounds.size.height == 736.0)
#define isIPADAIR ([UIScreen mainScreen].bounds.size.height == 1024.0)

//2048×1536


#define isIPHONEMIN ([UIScreen mainScreen].bounds.size.width == 320.0)
//判断是iphoneMAX
#define kYX_IS_IPHONEMAX ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone && [[UIScreen mainScreen] bounds].size.width > 320.0f)

//判断是iPad
#define EGODevice_iPad  (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)

//判断是iphone
#define kYX_IS_IPHONE ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)

//判断版本是否是7.0及以上
#define EGOVersion_iOS7 ([[UIDevice currentDevice].systemVersion doubleValue] >= 7.0)



// NSLog 的 relese 模式下不用输出信息
#ifdef DEBUG
#define NSLog(...) NSLog(__VA_ARGS__)
#define debugMethod() NSLog(@"%s", __func__)
#else
#define NSLog(...)
#define debugMethod()
#define DNSLog(...) NSLog(__VA_ARGS__)
#endif

#ifdef DEBUG
# define DLog(fmt, ...) NSLog((@"冯宝东模式:[文件名:%s]\n" "[函数名:%s]\n" "[行号:%d] \n" fmt), __FILE__, __FUNCTION__, __LINE__, ##__VA_ARGS__);
#else
# define DLog(...);
#endif

#define  FBD_MKRect(a,b,c,d)  CGRectMake(a,b,c,d)



//当前的宽高
#define Height_MY    [UIScreen mainScreen].bounds.size.height
#define Width_MY    [UIScreen mainScreen].bounds.size.width

#define VIEW_WIDTH      [UIScreen mainScreen].bounds.size.width
#define VIEW_HEIGHT     [UIScreen mainScreen].bounds.size.height

#define SELF_WIDTH      self.view.frame.size.width
#define SELF_HEIGHT     self.view.frame.size.height

#define USER_D [NSUserDefaults standardUserDefaults]
#define FILE_M [NSFileManager defaultManager]


#define USER_UID [[NSUserDefaults standardUserDefaults] objectForKey:@"uid"]
#define USER_TOKEN [[NSUserDefaults standardUserDefaults] objectForKey:@"token"]

#define ISDoctor [[NSUserDefaults standardUserDefaults] objectForKey:@"major"]

#define DoctorName [[NSUserDefaults standardUserDefaults] objectForKey:@"doctorsName"]


#define AuthorizationKey  @"Authorization"
#define BDAuthorization   [NSString stringWithFormat:@"Bearer %@",USER_TOKEN]
#define ProjectId [[NSUserDefaults standardUserDefaults] objectForKey:@"ProjectId"]



//颜色RGB值
#define RGB(rgb) [UIColor colorWithRed:(rgb)/255.0 green:(rgb)/255.0 blue:(rgb)/255.0 alpha:1.0]
#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
#define UIColorFromRGBA(rgbValue,A) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:A]
//bar的颜色
#define KBarColor [UIColor colorWithRed:244/255.0 green:94/255.0 blue:95/255.0 alpha:1]

#define UITF(float) [UIFont systemFontOfSize:float]

//对话框
#define SHOW_ALERT(msg) UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"温馨提醒" message:msg delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];\
[alert show];

#define SHOW_AOTUCLOSEALERT(msg) UIAlertView *alertSuccess = [[UIAlertView alloc]initWithTitle:@"温馨提示" message:msg delegate:nil cancelButtonTitle:nil otherButtonTitles:nil, nil];\
\
[alertSuccess show];\
\
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{\
    [alertSuccess dismissWithClickedButtonIndex:0 animated:YES];\
});



/**
 *      @author 冯宝东
 *
 *      导航栏的高度
 */
#define NavOrigixH    64.0f

#define FBDTabBarH    49.0f
/**
 *      @author 冯宝东
 *
 *      没有带tabBar的视图高度
 */
#define FBDViewH  (ScreenH-NavOrigixH)
/**
 *      @author 冯宝东
 *
 *      带有tabBar的视图高度
 */
#define FBDTabarViewH  (ScreenH-NavOrigixH-FBDTabBarH)

/**
 *      @author 冯宝东
 *
 *      Padding的大小宏定义
 */
#define PaddingLR10   10.f
#define PaddingLR15   15.f
#define PaddingLR12   12.f
#define PaddingT5     5.f
#define PaddingT10     10.f
#define PaddingT15     15.f

/**
 *      @author 冯宝东
 *
 *      线条的高度宏定义
 */
#define lineHeight     1.f
#define lineSlimHeight  0.5f

#define lineCustomColor UIColorFromRGB(0xe5e5e5)


/**
 *      @author 冯宝东
 *
 *      BLOCK 
 */
#define BDWeakSelf(type)  __weak typeof(type)weak##type=type
#define BDStrongSelf(type)  __strong typeof(type)strong##type=type


/**
 *  路径的定义
 *
 */
#define BD_HomeDir     NSHomeDirectory()
#define BD_Documents  [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES) objectAtIndex:0]

#define BD_VoicesDir    [NSString stringWithFormat:@"%@/fengVoice",BD_Documents]


#define SF_S(name)  [NSString stringWithFormat:@"%@",name]
#define SF_D(name)  [NSString stringWithFormat:@"%d",name]
#define SF_L(name)  [NSString stringWithFormat:@"%ld",name]

//通知的关键字
#define upLoadLastVoicesNotification   @"upLoadLastVoicesNotification"




//用户相关
#define VOICES_USER_NAME @"em_lastLogin_username"

//重要消息的 轮询 时间控制key
#define ImportantMSGTimeKey_YS @"ImportantMSGTimeKey_YS"
#define ImportantMSGTimeKey_HZ @"ImportantMSGTimeKey_HZ"



/**
 *      @author 冯宝东
 *
 *      接口API
 */
#define API_BingLi_Main  @"http://testedc.medsci.cn/api/v1/patient"
//testedc.medsci.cn  testedc.medsci.cn
#define API_VoicesURL    @"http://testedc.medsci.cn/api/v1/voices"
#define API_UpLoadVoicesURL @"http://testedc.medsci.cn/api/v1/uploadvoice"
#define API_NetWorkVoicesURL @"http://testedc.medsci.cn/api/v1/voices"
#define API_DeleteVoicesURL @"http://testedc.medsci.cn/api/v1/delaccessory"
#define API_ImportantMSGURL @"http://testedc.medsci.cn/api/v1/notice"
#define API_ImportantChangeStatus @"http://testedc.medsci.cn/api/v1/readnotice"
#define API_ImportantUnReadCount    @"http://testedc.medsci.cn/api/v1/unreadcount"

#define API_PersonUpLaodPhoto @"http://testedc.medsci.cn/api/v1/upavatar"

#define API_Login @"http://testedc.medsci.cn/api/v1/login"

#define API_PersonInfo @"http://testedc.medsci.cn/api/v1/info"

#endif

