//
//  FBDPopSelectView.m
//  NewMedSci
//
//  Created by feng on 16/5/30.
//  Copyright © 2016年 Bioon. All rights reserved.
//

#import "FBDPopSelectView.h"
#import "UIView+FBDQuickCreateUI.h"
@interface FBDPopSelectView ()
@property (nonatomic,strong)NSMutableArray*titleArray;

@end
@implementation FBDPopSelectView
{
    NSMutableArray*_beiTaiArray;// 这个是备胎
    FBDPopSelectViewBlock  _itemCallBlock;
}

/**
 *      @author 冯宝东
 *
 *      重写 FBDPopSelectView 的方法
 *
 *      @param frame 大小位置
 *
 *      @return 自定义的PopView 实例
 */
-(instancetype)initWithFrame:(CGRect)frame withTitleArray:(NSArray*)titleArray
{
    self=[super initWithFrame:frame];
    if (self)
    {
        _beiTaiArray=[NSMutableArray arrayWithArray:@[@"待选Item1",@"待选Item2",@"待选Item3"]];
        self.titleArray=[NSMutableArray arrayWithArray:titleArray];
        [self loadCustomView];
    }
    return self;
}
/**
 *      @author 冯宝东
 *
 *      每个Item 的回调点击
 */
-(void)popSelectViewOfItemCallBack:(FBDPopSelectViewBlock)callBlock
{
    _itemCallBlock=[callBlock copy];

}

// 布局UI
-(void)loadCustomView{
    if (_titleArray.count==0)
    {
        _titleArray=_beiTaiArray;
    }
    int index=1;
    for (NSString* titleTip in _titleArray)
    {
        UIView*everyView=[self everyItemViewWithTitle:titleTip indexTag:index];
        [self addSubview:everyView];
        index++;
    }
    
    [self setView_sizeHeight:index*60];
    
}


-(UIView*)everyItemViewWithTitle:(NSString*)title indexTag:(NSInteger)tag
{
    UIView*everyView=[self fbd_quickCreateUIViewWithFrame:CGRectMake(0, tag*60, CGRectGetWidth(self.frame), 60)];
    everyView.tag=tag;
    UITapGestureRecognizer* tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(everyItemPressed:)];
    tap.numberOfTapsRequired=1;
    [everyView addGestureRecognizer:tap];
    UILabel*everyTipLabel=[self fbd_quickCreateUILabelWithFrame:everyView.bounds];
    everyTipLabel.text=title;
    everyTipLabel.textAlignment=NSTextAlignmentCenter;
    [everyView addSubview:everyTipLabel];
    if (tag<_titleArray.count)
    {
        UIView*bottomLine=[self  fbd_quickCreateUIViewWithFrame:CGRectMake(0, 60-0.5, CGRectGetWidth(self.frame), 0.5)];
        bottomLine.backgroundColor=UIColorFromRGB(0xe5e5e5);
        [everyView addSubview:bottomLine];
    }

    return everyView;
}

-(void)everyItemPressed:(UITapGestureRecognizer*)sender
{
    UIView* tapView=(UIView*)sender.view;
    if (_itemCallBlock)
    {
        _itemCallBlock(tapView.tag);
        
    }
    

}


@end
