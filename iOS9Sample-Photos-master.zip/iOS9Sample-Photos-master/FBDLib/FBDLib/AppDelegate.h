//
//  AppDelegate.h
//  EDCsfzs
//
//  Created by M-SJ076 on 16/8/15.
//  Copyright © 2016年 牛高航. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;



@end

