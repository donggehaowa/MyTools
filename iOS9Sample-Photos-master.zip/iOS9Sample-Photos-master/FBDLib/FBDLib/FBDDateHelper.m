//
//  FBDDateHelper.m
//  NewMedSci
//
//  Created by feng on 16/6/7.
//  Copyright © 2016年 Bioon. All rights reserved.
//

#import "FBDDateHelper.h"
#define USER_D [NSUserDefaults standardUserDefaults]
static FBDDateHelper *singleTan;
@implementation FBDDateHelper
{

    NSDateFormatter*myFormatter;
    DateHelperBlock _insideBlocks;
    DateHelperBlock _outsideBlocks;
    
}

/**
 *      @author 冯宝东
 *
 *      类的构造方法
 *
 *      @return Date的实例助手
 */
+(instancetype)defaultTools
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singleTan=[[self alloc]init];
        singleTan->myFormatter=[[NSDateFormatter alloc] init];
        NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
        [singleTan->myFormatter setTimeZone:timeZone];
        [singleTan->myFormatter setDateFormat:@"yyyy年MM月dd日|HH时mm分ss秒"];
        
    });

    return singleTan;
}

/**
 *      @author 冯宝东
 *
 *      返回自定义的时间字符串
 *
 *      @return 现在的时间字符串
 */
-(NSString*)fbd_getNowDateString
{
    NSDate*myNowDate=[NSDate date];
    NSString*nowString=[self->myFormatter  stringFromDate:myNowDate];
    return nowString;
//    yyyy-MM-dd hh:mm:ss
    return @"2016年6月7日|13时43分00秒";
}

/**
 *      @author 冯宝东
 *
 *      返回多少秒之后的时间字符串
 *
 *      @param second 秒数
 *
 *      @return second 秒之后的时间字符串
 */
-(NSString*)fbd_getDateStringAfterMuchSecond:(NSInteger)second
{
    NSDate*afterSecondDate=[NSDate dateWithTimeIntervalSinceNow:second];
    NSString*afterString=[self->myFormatter  stringFromDate:afterSecondDate];
    return afterString;
    return @"2006年6月7日|13时43分00秒";

}
/**
 *      @author 冯宝东
 *
 *      用两个block函数来判定在多少（5分钟）时间内执行什么 多少时间之外执行什么
 *
 *      @param seconds      秒数
 *      @param timeKey      时间标示
 *      @param insideBlock  秒数之内
 *      @param outsideBlock 秒数之外
 */
-(void)fbd_setHowManyTimes:(NSInteger)seconds timeKey:(NSString*)timeKey  insideBlock:(DateHelperBlock)insideBlock outsideBlock:(DateHelperBlock)outsideBlock
{
    _insideBlocks=[insideBlock copy];
    _outsideBlocks=[outsideBlock copy];
    
    NSString*tommorrowShopTime=[USER_D objectForKey:timeKey];
    NSComparisonResult result= [[FBDDateHelper defaultTools]fbd_compareNowDateWithIndexDateString:tommorrowShopTime];
    // 5分钟之内返回缓存里面的东西  5分钟之后请求最新的数据
    if (result==NSOrderedAscending)
    {
        _insideBlocks();
        
    }else
    {
        _outsideBlocks();
        NSString*tommorrowShopTime=[[FBDDateHelper defaultTools] fbd_getDateStringAfterMuchSecond:seconds];
        [USER_D setObject:tommorrowShopTime forKey:timeKey];
        [USER_D synchronize];
    }
}

/**
 *      @author 冯宝东
 *
 *      返回多少天之后的零晨零分零秒
 *
 *      @param day 多少天
 *
 *      @return 某天的凌晨时刻
 */
-(NSString*)fbd_getZoreHoursZoreMinterDateStringAfterMuchDay:(NSInteger)day
{
    NSDate*indexDayDate=[NSDate dateWithTimeIntervalSinceNow:day*24*60*60];
    NSString*indexDateString=[self->myFormatter stringFromDate:indexDayDate];
    NSString*firstHalf=[[indexDateString componentsSeparatedByString:@"|"] firstObject];
    
    NSString* allTime=[NSString stringWithFormat:@"%@|%@",firstHalf,@"00时00分00秒"];
    return allTime;
    return @"2006年6月7日|00时00分00秒";
}

/**
 *      @author 冯宝东
 *
 *      拿现在的时间和指定的时间做比较
 *
 *      @param indexDateString 指定的时间字符串
 *
 *      @return 比较的结果
 */
-(NSComparisonResult)fbd_compareNowDateWithIndexDateString:(NSString*)indexDateString
{
    NSDate*compareNowDate=[NSDate date];
    NSDate*compareFutureDate=[self->myFormatter dateFromString:indexDateString];
    NSComparisonResult result=[compareNowDate compare:compareFutureDate];
    return result;
}
/**
 *      @author 冯宝东
 *
 *      比较两个指定的字符床的时间大小
 *
 *      @param dateOne 指定的时间1号
 *      @param dateTwo 指定的时间2号
 *
 *      @return 比较结果
 */
-(NSComparisonResult)fbd_compareIndexOneDate:(NSString*)dateOne otherDate:(NSString*)dateTwo
{
    NSDate*compareDateOne=[self->myFormatter dateFromString:dateOne];
    NSDate*compareDateTwo=[self->myFormatter dateFromString:dateTwo];
    NSComparisonResult result=[compareDateOne compare:compareDateTwo];
    return result;
}


-(NSString*)getsevenHoursZoreMinterDateStringAfterMuchDay:(NSInteger)day
{
    NSDate*indexDayDate=[NSDate dateWithTimeIntervalSinceNow:day*24*60*60];
    NSString*indexDateString=[self->myFormatter stringFromDate:indexDayDate];
    NSString*firstHalf=[[indexDateString componentsSeparatedByString:@"|"] firstObject];
    
    NSString* allTime=[NSString stringWithFormat:@"%@|%@",firstHalf,@"19时00分00秒"];
    return allTime;
    return @"2006年6月7日|00时00分00秒";
}

@end
