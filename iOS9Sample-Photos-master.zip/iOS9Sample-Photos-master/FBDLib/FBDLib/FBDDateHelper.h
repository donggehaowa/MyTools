//
//  FBDDateHelper.h
//  NewMedSci
//
//  Created by feng on 16/6/7.
//  Copyright © 2016年 Bioon. All rights reserved.
//
typedef void(^DateHelperBlock)(void);
#import <Foundation/Foundation.h>

@interface FBDDateHelper : NSObject
/**
 *      @author 冯宝东
 *
 *      类的构造方法
 *
 *      @return Date的实例助手
 */
+(instancetype)defaultTools;

/**
 *      @author 冯宝东
 *
 *      返回自定义的时间字符串
 *
 *      @return 现在的时间字符串
 */
-(NSString*)fbd_getNowDateString;

/**
 *      @author 冯宝东
 *
 *      返回多少秒之后的时间字符串
 *
 *      @param second 秒数
 *
 *      @return second 秒之后的时间字符串
 */
-(NSString*)fbd_getDateStringAfterMuchSecond:(NSInteger)second;


/**
 *      @author 冯宝东
 *
 *      用两个block函数来判定在多少（5分钟）时间内执行什么 多少时间之外执行什么
 *
 *      @param seconds      秒数
 *      @param seconds      秒数
 *      @param insideBlock  秒数之内
 *      @param outsideBlock 秒数之外
 */
-(void)fbd_setHowManyTimes:(NSInteger)seconds timeKey:(NSString*)timeKey  insideBlock:(DateHelperBlock)insideBlock outsideBlock:(DateHelperBlock)outsideBlock;




/**
 *      @author 冯宝东
 *
 *      返回多少天之后的零晨零分零秒
 *
 *      @param day 多少天
 *
 *      @return 某天的凌晨时刻
 */
-(NSString*)fbd_getZoreHoursZoreMinterDateStringAfterMuchDay:(NSInteger)day;


/**
 *      @author 冯宝东
 *
 *      拿现在的时间和指定的时间做比较
 *
 *      @param indexDateString 指定的时间字符串
 *
 *      @return 比较的结果
 */
-(NSComparisonResult)fbd_compareNowDateWithIndexDateString:(NSString*)indexDateString;
/**
 *      @author 冯宝东
 *
 *      比较两个指定的字符床的时间大小
 *
 *      @param dateOne 指定的时间1号
 *      @param dateTwo 指定的时间2号
 *
 *      @return 比较结果
 */
-(NSComparisonResult)fbd_compareIndexOneDate:(NSString*)dateOne otherDate:(NSString*)dateTwo;



-(NSString*)getsevenHoursZoreMinterDateStringAfterMuchDay:(NSInteger)day;


@end
