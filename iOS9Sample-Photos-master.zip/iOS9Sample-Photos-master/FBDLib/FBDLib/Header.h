//
//  Header.h
//  EDCsfzs
//
//  Created by M-SJ076 on 16/8/16.
//  Copyright © 2016年 牛高航. All rights reserved.
//



#ifdef __OBJC__
#import <UIKit/UIKit.h>
#import "IOS7IOS6Macth.h"


/**
 *  用户Token
 *
 *  @return token
 */
#define AUTHORIZATION_Bearer [NSString stringWithFormat:@"Bearer %@",USER_TOKEN]



#define LoginGroop [NSHomeDirectory() stringByAppendingString:@"/LoginGroop.plist"]




#endif /* Header_h */
