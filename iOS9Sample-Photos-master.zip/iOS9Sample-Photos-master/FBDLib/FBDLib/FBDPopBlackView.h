//
//  FBDPopBlackView.h
//  NewMedSci
//
//  Created by feng on 16/5/30.
//  Copyright © 2016年 Bioon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface FBDPopBlackView : UIView
@property (nonatomic,assign) NSInteger showMode;

/**
 *      @author 冯宝东
 *
 *      类方法的单例模式
 *
 *      @return popView的实例
 */
+(instancetype)defaultPopView;

/**
 *      @author 冯宝东
 *
 *      展示在window中
 */
-(void)showInWindow;
/**
 *      @author 冯宝东
 *
 *      把内容视图展示在KeyWindow上
 *
 *      @param contentView 内容视图
 */
-(void)showInWindowWithContentView:(UIView*)contentView;
/**
 *      @author 冯宝东
 *
 *      让单例在 window上面消失
 */
-(void)dismissShowInWindow;
@end
