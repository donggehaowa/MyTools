//
//  FBDPopBlackView.m
//  NewMedSci
//
//  Created by feng on 16/5/30.
//  Copyright © 2016年 Bioon. All rights reserved.
//

#import "FBDPopBlackView.h"
#import "FBDPopBlackView.h"
#import "UIView+FBDQuickCreateUI.h"
static FBDPopBlackView* singlTan;
@interface FBDPopBlackView()
{
    UIView* _myContentView;
    UIView*_blackView;
}

@end
@implementation FBDPopBlackView
/**
 *      @author 冯宝东
 *
 *      类方法的单例模式
 *
 *      @return popView的实例
 */
+(instancetype)defaultPopView
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singlTan=[[self alloc] initWithFrame:[UIScreen mainScreen].bounds];
    });
    return singlTan;
}

-(void)showInWindow
{

    singlTan.backgroundColor=[UIColor clearColor];
    _blackView=[[UIView alloc] initWithFrame:singlTan.bounds];
    _blackView.backgroundColor=[UIColor blackColor];
    _blackView.alpha=0.6;
    [singlTan addSubview:_blackView];
    UIWindow* myMainWindow=[UIApplication sharedApplication].keyWindow;
    if (myMainWindow)
    {
        [myMainWindow makeKeyWindow];
        [myMainWindow addSubview:singlTan];
        
    }else
    {
        [self performSelector:@selector(laterForAddWindow) withObject:nil afterDelay:0.01];
    }
    
    
}

/**
 *      @author 冯宝东
 *
 *      把内容视图展示在KeyWindow上
 *
 *      @param contentView 内容视图
 */
-(void)showInWindowWithContentView:(UIView*)contentView
{
    [self performSelector:@selector(afterDelayShowInWindowWithContentView:) withObject:contentView afterDelay:0.01];
}
-(void)afterDelayShowInWindowWithContentView:(UIView*)contentView
{
 
    [self.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj removeFromSuperview];
        obj=nil;
    }];
    [self showInWindow];
    _myContentView=contentView;
    [singlTan addSubview:contentView];
    
    CGFloat contentHeigh=CGRectGetHeight(contentView.frame);
    CGFloat singlTanHeigh=singlTan.frame.size.height;
    CGFloat originY=singlTanHeigh-contentHeigh;
    
    [contentView setView_orignY:singlTanHeigh];
    [UIView animateWithDuration:0.2 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
    [contentView setView_orignY:originY];
    } completion:nil];



}

/**
 *      @author 冯宝东
 *
 *      让页面消失的方法
 */
-(void)downClosePopBackView
{
    [UIView animateKeyframesWithDuration:0.2 delay:0 options:UIViewKeyframeAnimationOptionLayoutSubviews animations:^{
        [_myContentView setView_orignY:CGRectGetHeight(singlTan.frame)];
        _blackView.alpha=0;
    } completion:^(BOOL finished){
    [self.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
    [obj removeFromSuperview];
    obj=nil;
    }];
         [singlTan removeFromSuperview];
    }];
    
}

/**
 *      @author 冯宝东
 *
 *      让单例在 window上面消失
 */
-(void)dismissShowInWindow
{
    [self downClosePopBackView];
}



-(void)laterForAddWindow
{
    singlTan.backgroundColor=[UIColor brownColor];
    UIWindow* myMainWindow=[UIApplication sharedApplication].keyWindow;
    if (!myMainWindow){
        id <UIApplicationDelegate> myAppDelegate=[UIApplication sharedApplication].delegate;
        myMainWindow=[myAppDelegate window];
        [myMainWindow makeKeyWindow];
    }
    [myMainWindow addSubview:singlTan];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
        UITouch *touch = [touches anyObject];
        if (touch.view==_blackView)
        {
            [self downClosePopBackView];
    
            [self endEditing:YES];
        }
}

@end
