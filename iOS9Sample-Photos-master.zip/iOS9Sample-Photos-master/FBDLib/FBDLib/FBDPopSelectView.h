//
//  FBDPopSelectView.h
//  NewMedSci
//
//  Created by feng on 16/5/30.
//  Copyright © 2016年 Bioon. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^FBDPopSelectViewBlock)(NSInteger index);
@interface FBDPopSelectView : UIView
/**
 *      @author 冯宝东
 *
 *      重写 FBDPopSelectView 的方法
 *
 *      @param frame 大小位置
 *
 *      @return 自定义的PopView 实例
 */
-(instancetype)initWithFrame:(CGRect)frame withTitleArray:(NSArray*)titleArray;
/**
 *      @author 冯宝东
 *
 *      每个Item 的回调点击
 */
-(void)popSelectViewOfItemCallBack:(FBDPopSelectViewBlock)callBlock;

@end
