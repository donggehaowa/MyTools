//
//  ViewController.m
//  iOS9Sample-Photos
//
//  Created by MJ Lee on 15/9/24.
//  Copyright © 2015年 小码哥（http://www.520it.com）. All rights reserved.
//

#import "ViewController.h"
#import <Photos/Photos.h>
#import "FBDPictureViewController.h"

/** 相册名字 */
static NSString * const XMGCollectionName = @"冯哥-Photos";

@interface ViewController ()
{
    FBDPictureViewController* pictureVC;
}
@property (nonatomic,strong)NSMutableArray* listPictureArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.listPictureArray=[NSMutableArray array];
    
    
}

/**
 * 获得自定义的相册对象
 */
- (PHAssetCollection *)collection
{
    // 先从已存在相册中找到自定义相册对象
    PHFetchResult<PHAssetCollection *> *collectionResult = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeAlbum subtype:PHAssetCollectionSubtypeAlbumRegular options:nil];
    for (PHAssetCollection *collection in collectionResult) {
        if ([collection.localizedTitle isEqualToString:XMGCollectionName]) {
            return collection;
        }
    }
    
    // 新建自定义相册
    __block NSString *collectionId = nil;
    NSError *error = nil;
    [[PHPhotoLibrary sharedPhotoLibrary] performChangesAndWait:^{
        collectionId = [PHAssetCollectionChangeRequest creationRequestForAssetCollectionWithTitle:XMGCollectionName].placeholderForCreatedAssetCollection.localIdentifier;
    } error:&error];
    
    if (error) {
        NSLog(@"创建相册【%@】失败", XMGCollectionName);
        return nil;
    }
    
    
    
    return [PHAssetCollection fetchAssetCollectionsWithLocalIdentifiers:@[collectionId] options:nil].lastObject;
}

/**
 * 保存图片到相册
 */
- (IBAction)saveImage {
    PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
    if (status == PHAuthorizationStatusDenied) {
        NSLog(@"请到【设置-隐私-照片】打开访问开关");
    } else if (status == PHAuthorizationStatusRestricted) {
        NSLog(@"无法访问相册");
    } else {
        // 保存相片的标识
        __block NSString *assetId = nil;
        
        [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
            // 保存相片到相机胶卷，并返回标识
            assetId = [PHAssetCreationRequest creationRequestForAssetFromImage:[UIImage imageNamed:@"logo"]].placeholderForCreatedAsset.localIdentifier;
        } completionHandler:^(BOOL success, NSError * _Nullable error) {
            if (!success) {
                NSLog(@"保存失败：%@", error);
                return;
            }
            
            // 根据标识获得相片对象
            PHAsset *asset = [PHAsset fetchAssetsWithLocalIdentifiers:@[assetId] options:nil].lastObject;
            
            // 拿到自定义的相册对象
            PHAssetCollection *collection = [self collection];
            if (collection == nil) return;
            
            // 保存相片到自定义相册中
            [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
                [[PHAssetCollectionChangeRequest changeRequestForAssetCollection:collection] addAssets:@[asset]];
            } completionHandler:^(BOOL success, NSError * _Nullable error) {
                if (success) {
                    NSLog(@"保存成功");
                } else {
                    NSLog(@"保存失败：%@", error);
                }
            }];
        }];
    }
}

/**
 * 查询所有的图片
 */
- (IBAction)searchAllImages {
    
//    // 遍历所有的自定义相册
    dispatch_queue_t queue =dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0);
    dispatch_async(queue, ^{
        
        PHFetchResult<PHAssetCollection *> *collectionResult0 = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeSmartAlbum subtype:PHAssetCollectionSubtypeAlbumRegular options:nil];
        for (PHAssetCollection *collection in collectionResult0) {
            [self searchAllImagesInCollection:collection];
        }
        [self showFBDPictureViewController];

        dispatch_sync(dispatch_get_main_queue(), ^{

        NSLog(@"_listPictureArray 的数量count：%ld",_listPictureArray.count);
        pictureVC.pictureListArray=_listPictureArray;
        [pictureVC reloadCollectionView];
            

            
        });
        
        
    });
    
    [self performSelector:@selector(showFBDPictureViewController) withObject:nil afterDelay:0.1];
    
}

/**
 * 查询某个相册里面的所有图片
 */
- (void)searchAllImagesInCollection:(PHAssetCollection *)collection
{
    // 采取同步获取图片（只获得一次图片）
    PHImageRequestOptions *imageOptions = [[PHImageRequestOptions alloc] init];
    imageOptions.synchronous = YES;
    imageOptions.resizeMode=PHImageRequestOptionsResizeModeFast;
    imageOptions.networkAccessAllowed=NO;
    imageOptions.progressHandler=^(double progress, NSError *__nullable error, BOOL *stop, NSDictionary *__nullable info)
    {
        NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>>>>%f",progress);
        
        
    };
    NSLog(@"相册名字：%@", collection.localizedTitle);
    
    // 遍历这个相册中的所有图片
    PHFetchResult<PHAsset *> *assetResult = [PHAsset fetchAssetsInAssetCollection:collection options:nil];
    for (PHAsset *asset in assetResult) {
        // 过滤非图片
        if (asset.mediaType != PHAssetMediaTypeImage) continue;
        
        // 图片原尺寸
        CGSize targetSize = CGSizeMake(asset.pixelWidth/50.0, asset.pixelHeight/50.0);
//        targetSize=CGSizeMake(100, 100/2.5);
       
        
        
        
        
        
        
        
        
        // 请求图片
        [[PHImageManager defaultManager] requestImageForAsset:asset targetSize:targetSize contentMode:PHImageContentModeDefault options:imageOptions resultHandler:^(UIImage * _Nullable result, NSDictionary * _Nullable info) {
            
            /*
             
             {
             PHImageFileOrientationKey = 0;
             PHImageFileSandboxExtensionTokenKey = "709eba02e1dbf6bd9fdf0938890d4c79a3843010;00000000;00000000;000000000000001a;com.apple.app-sandbox.read;00000001;01000004;0000000000d2a9c0;/users/feng/library/developer/coresimulator/devices/d35bd2b3-8ed7-4e72-817e-1f788035a392/data/media/dcim/100apple/img_0010.jpg";
             PHImageFileURLKey = "file:///Users/feng/Library/Developer/CoreSimulator/Devices/D35BD2B3-8ED7-4E72-817E-1F788035A392/data/Media/DCIM/100APPLE/IMG_0010.JPG";
             PHImageFileUTIKey = "public.jpeg";
             PHImageResultDeliveredImageFormatKey = 9999;
             PHImageResultIsDegradedKey = 0;
             PHImageResultIsInCloudKey = 0;
             PHImageResultIsPlaceholderKey = 0;
             PHImageResultWantedImageFormatKey = 4035;
             }
             
             */
            NSLog(@"图片：%@ /n info :%@", result,info);
            if (result)
            {
                        [self.listPictureArray addObject:result];
            }

            
        }];
    }
}



-(void)showFBDPictureViewController
{
    pictureVC=[[FBDPictureViewController alloc] init];
    pictureVC.pictureListArray=_listPictureArray;
    pictureVC.view.backgroundColor=[UIColor whiteColor];
    [self presentViewController:pictureVC animated:YES completion:^{
        NSLog(@" present  进入了picktureViewController 视图控制器");
    }];
}








- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
    NSLog(@"didReceiveMemoryWarningFrom ViewController");
    
}



@end
