//
//  AppDelegate.m
//  iOS9Sample-Photos
//
//  Created by MJ Lee on 15/9/24.
//  Copyright © 2015年 小码哥. All rights reserved.
//

#import "AppDelegate.h"
#import <UserNotifications/UserNotifications.h>
@interface AppDelegate ()<UNUserNotificationCenterDelegate>

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    

//#if FBDMAC>=1
    //iOS 10
    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    center.delegate=self;
    [center requestAuthorizationWithOptions:(UNAuthorizationOptionBadge | UNAuthorizationOptionSound | UNAuthorizationOptionAlert) completionHandler:^(BOOL granted, NSError * _Nullable error) {
        if (!error) {
            //            NSLog(@"request authorization succeeded!");
        }
        
    }];
    [center getNotificationSettingsWithCompletionHandler:^(UNNotificationSettings * _Nonnull settings) {
        //        NSLog(@"用户设置如下:\n%@",settings);
    }];
    
    [[UIApplication sharedApplication] registerForRemoteNotifications];
    
    //Local Notification
    UNMutableNotificationContent *content = [[UNMutableNotificationContent alloc] init];
    content.title = @"Introduction to Notifications";
    content.subtitle = @"Session 707";
    content.body = @"Woah! These new notifications look amazing! Don’t you agree?";
    content.badge = @999;
    
    UNNotificationSound *sound=[UNNotificationSound soundNamed:@"medsci_sound"];
    content.sound=sound;
    content.launchImageName=@"ren";
    
    NSURL *myurl = [[NSBundle mainBundle] URLForResource:@"ren" withExtension:@"png"];
    NSError*error=nil;
    UNNotificationAttachment* attacheMentImage=[UNNotificationAttachment attachmentWithIdentifier:@"sampleReques11t" URL:myurl options:nil error:&error];
    if (error) {
        NSLog(@"error message is %@",error.localizedDescription);
    }
    content.attachments=@[attacheMentImage];
    
    NSMutableArray* actionM_Array=[NSMutableArray array];
    UNNotificationAction*actionA=[UNNotificationAction actionWithIdentifier:@"actionA" title:@"A_Action" options:UNNotificationActionOptionAuthenticationRequired];
    UNNotificationAction*actionB=[UNNotificationAction actionWithIdentifier:@"actionB" title:@"B_Action" options:UNNotificationActionOptionDestructive];
    UNNotificationAction*actionC=[UNNotificationAction actionWithIdentifier:@"actionC" title:@"C_Action" options:UNNotificationActionOptionForeground];
    [actionM_Array addObject:actionA];
    [actionM_Array addObject:actionB];
    [actionM_Array addObject:actionC];
    
    UNNotificationCategory* notificationCate=[UNNotificationCategory categoryWithIdentifier:@"myCate" actions:actionM_Array intentIdentifiers:@[] options:UNNotificationCategoryOptionCustomDismissAction];
    
    [center setNotificationCategories:[NSSet setWithObjects:notificationCate, nil]];
    
    content.categoryIdentifier=@"myCate";
    
    
    //0.1 分钟后提醒
    UNTimeIntervalNotificationTrigger *trigger1 = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:6 repeats:NO];
    NSString *requestIdentifier = @"sampleRequest";
    UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:requestIdentifier
                                                                          content:content
                                                                          trigger:trigger1];
    [center addNotificationRequest:request withCompletionHandler:^(NSError * _Nullable error) {
        
    }];

//#endif
    
    
    
    return YES;
}
#pragma mark-  前台接受后 将要呈现的内容
-(void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler{
    
    
    
    
    
    completionHandler(UNNotificationPresentationOptionAlert | UNNotificationPresentationOptionSound);
    
}
#pragma mark-  后台接收后 将要呈现的内容
- (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void(^)())completionHandler
{

    completionHandler();
    
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
