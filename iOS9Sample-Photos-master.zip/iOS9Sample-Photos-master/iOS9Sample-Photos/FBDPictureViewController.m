//
//  FBDPictureViewController.m
//  iOS9Sample-Photos
//
//  Created by feng on 16/3/7.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#define  cellIndentifi @"collectionCells"
#import "FBDPictureViewController.h"
#import "FBDPictureCollectionViewCell.h"

@interface FBDPictureViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
@property (nonatomic,strong)UICollectionView* collectionView;
@end

@implementation FBDPictureViewController
{
    NSTimer* myReloadTimer;
}
-(instancetype)init
{
    self=[super init];
    
    UICollectionViewFlowLayout*flowLayout=[[UICollectionViewFlowLayout alloc] init];
    flowLayout.itemSize=CGSizeMake(100, 100);
    flowLayout.sectionInset=UIEdgeInsetsMake(20,10, 20, 10);
    _collectionView=[[UICollectionView alloc] initWithFrame:[[UIScreen mainScreen]bounds] collectionViewLayout:flowLayout];
    _collectionView.backgroundColor=[UIColor brownColor];
    _collectionView.delegate=self;
    _collectionView.dataSource=self;
    [_collectionView registerClass:[FBDPictureCollectionViewCell class] forCellWithReuseIdentifier:cellIndentifi];
    [self.view addSubview:_collectionView];
    
   myReloadTimer=[ NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(timeToRelaodCollectionView) userInfo:nil repeats:YES];
    
    return self;

}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    
    
    
    
    
    
}
-(void)setPictureListArray:(NSMutableArray *)pictureListArray
{
    _pictureListArray=pictureListArray;
    
    NSLog(@"setPictureListArrayFor_pictureListArray数量：%ld",_pictureListArray.count);
    [_collectionView reloadData];


}
#pragma mark ----------UICollectionViewDataSource,UICollectionViewDelegate
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return   _pictureListArray.count;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    FBDPictureCollectionViewCell* cell=[collectionView dequeueReusableCellWithReuseIdentifier:cellIndentifi forIndexPath:indexPath];
    
    NSInteger row=indexPath.row;
    UIImage* indexDic=[_pictureListArray objectAtIndex:row];
    
    cell.middeImageView.image=indexDic;
    
    
    
    
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
    

}
/**
 *      @author 冯宝东
 *
 *      最后一次关了定时器
 */
-(void)reloadCollectionView
{
    
    dispatch_async(dispatch_get_main_queue(), ^{
       
        [_collectionView reloadData];
        [myReloadTimer invalidate];
        myReloadTimer=nil;
        
    });
   

}

-(void)timeToRelaodCollectionView
{

    [_collectionView reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.



}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
