//
//  FBDPictureCollectionViewCell.m
//  iOS9Sample-Photos
//
//  Created by feng on 16/3/7.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "FBDPictureCollectionViewCell.h"

@implementation FBDPictureCollectionViewCell
-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if(self)
    {
        _middeImageView=[[UIImageView alloc] initWithFrame:self.bounds];
        _middeImageView.backgroundColor=[UIColor grayColor];
        _middeImageView.contentMode=UIViewContentModeScaleToFill;
        [self.contentView addSubview:_middeImageView];
    
    }
    
    return self;

}
@end
