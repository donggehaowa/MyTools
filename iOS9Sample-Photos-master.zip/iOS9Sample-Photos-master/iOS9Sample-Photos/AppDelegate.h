//
//  AppDelegate.h
//  iOS9Sample-Photos
//
//  Created by MJ Lee on 15/9/24.
//  Copyright © 2015年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

