//
//  FBDPictureViewController.h
//  iOS9Sample-Photos
//
//  Created by feng on 16/3/7.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FBDPictureViewController : UIViewController
@property (nonatomic,strong)NSMutableArray* pictureListArray;
-(void)reloadCollectionView;
@end
