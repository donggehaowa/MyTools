//
//  FBDPictureCollectionViewCell.h
//  iOS9Sample-Photos
//
//  Created by feng on 16/3/7.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>




@interface FBDPictureCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong)UIImageView* middeImageView;
@end
