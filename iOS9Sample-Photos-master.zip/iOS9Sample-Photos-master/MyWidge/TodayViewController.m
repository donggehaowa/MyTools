//
//  TodayViewController.m
//  MyWidge
//
//  Created by feng on 16/10/9.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "TodayViewController.h"
#import <NotificationCenter/NotificationCenter.h>

@interface TodayViewController () <NCWidgetProviding>

@end

@implementation TodayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.view.backgroundColor=[UIColor lightGrayColor];
    
    UIButton* oneButton=[[UIButton alloc] initWithFrame:CGRectMake(10, 10, 50, 30)];
    [oneButton addTarget:self action:@selector(oneButtonPressed) forControlEvents:UIControlEventTouchUpInside];
    oneButton.backgroundColor=[UIColor greenColor];
    oneButton.titleLabel.font=[UIFont systemFontOfSize:10];
    [oneButton setTitle:@"A Action" forState:UIControlStateNormal];
    [self.view addSubview:oneButton];
    
    UIButton* twoButton=[[UIButton alloc] initWithFrame:CGRectMake(80, 10, 50, 30)];
    twoButton.titleLabel.font=[UIFont systemFontOfSize:10];
    [twoButton setTitle:@"B Action" forState:UIControlStateNormal];
    [self.view addSubview:twoButton];
    
    
    
}

-(void)oneButtonPressed
{

    [self.extensionContext openURL:[NSURL URLWithString:@"MedSci://feng:www.baidu.com"]  completionHandler:^(BOOL success) {
    }];
    

    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)widgetPerformUpdateWithCompletionHandler:(void (^)(NCUpdateResult))completionHandler {
    // Perform any setup necessary in order to update the view.
    
    // If an error is encountered, use NCUpdateResultFailed
    // If there's no update required, use NCUpdateResultNoData
    // If there's an update, use NCUpdateResultNewData

    completionHandler(NCUpdateResultNewData);
}

@end
